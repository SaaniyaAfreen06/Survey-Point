<div class="col-12">
	<hr>
		<p align="center" style="font-size: 0.9em">
		 Copyrights &copy;  All Rights Reserved<br>
		</p>
</div>
