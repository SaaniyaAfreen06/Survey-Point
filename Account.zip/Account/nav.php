<nav class="navbar navbar-default navbar-fixed-top " style="background: #0d2f79">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#" style="color: #ffffff;font: Times New Roman"><h5><b>&nbsp;&nbsp;&nbsp;SURVEY KING</b></h5></a> 
    </div>
    <div class="collapse navbar-collapse" id="myNavbar" style="color:white" >
      <h4><ul class="nav navbar-nav">
          <li><a href="index.php"><b>HOME</b></a></li>
          <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href=""><b>SURVEY</b>&nbsp;<span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="Survey_dashboard.php"><b>SURVEY DASHBOARD</b></a></li>
              <li><a href="create_Survey.php"><b>CREATE NEW SURVEY</b></a></li>
              <li><a href="Visit_Survey.php"><b>VISIT SURVEY</b></a></li>
            </ul>
          </li>
          <li><a href="Profile.php"><b>PROFILE</b></a></li>
          <li><a href="../ContactUs.php" ><b>CONTACT US</b></a></li>
        </ul></h4>
    
      <ul class="nav navbar-nav navbar-right" >
      <li><button class="btn btn-lg btn-inverse" style="background: #0d2f79;color: white" onclick="location.href='logout.php?logout'" ><span class="glyphicon glyphicon-log-out"></span>&nbsp;&nbsp;LOGOUT</button></li>
      </ul>
    </div>
  </div>
</nav>