
<div class="container-fluid" >
  <div class="row">
  <div class="col-xs-2" >
  	<img src="../indept-assets/lo.png" align="middle" style="height: 15vw;margin: 15px;" >
  </div>
</div>
</div>


<nav class="navbar navbar-inverse" data-spy="affix" data-offset-top="10007">
  <div class="container-fluid">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>                        
      </button>
    </div>
    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
          <li><a href="index.php"><b>HOME</b></a></li>
          <li><a href="User.php"><b>USERS</b></a></li>
          <li><a href="survey.php"><b>SURVEYS</b></a></li>
          <li><a href="../ContactUs.php" ><b>CONTACT US</b></a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
    		 <li><a href="logout.php?logout"  >&nbsp;&nbsp;|&nbsp;LOGOUT </a></li>
    	</ul>
      </div>
    </div>
  </div>
</nav>  